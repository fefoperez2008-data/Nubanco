
#include <stdio.h>
#include <string.h>
#include <math.h>

// Prototipos das funcoes
void exibirMenu();
int validarCPF(char cpf[]);
int cadastrarCliente(char nome[], char cpf[], float *saldo);
void realizarTransferencia(float *saldo);
void solicitarEmprestimo();
void consultarSaldo(float saldo);

int main() {
    int opcao;
    int cadastroConfirmado = 0;

    char nome[100];
    char cpf[12];

    float saldo = 0.0;

    printf("================================\n");
    printf("             NuBanco\n");
    printf("================================\n");
    printf("Sistema de simulacao bancaria\n");

    do {
        exibirMenu();

        printf("\nEscolha uma opcao: ");

        if (scanf("%d", &opcao) != 1) {
            printf("\nEntrada invalida. Digite um numero.\n");

            int caractere;
            while ((caractere = getchar()) != '\n' &&
                   caractere != EOF) {
                // Limpa a entrada invalida
            }

            continue;
        }

        switch (opcao) {
            case 1:
                if (cadastroConfirmado == 0) {
                    cadastroConfirmado =
                        cadastrarCliente(nome, cpf, &saldo);
                } else {
                    printf("\nJa existe um cadastro nesta sessao.\n");
                }
                break;

            case 2:
                if (cadastroConfirmado == 1) {
                    realizarTransferencia(&saldo);
                } else {
                    printf("\nRealize o cadastro antes de transferir.\n");
                }
                break;

            case 3:
                if (cadastroConfirmado == 1) {
                    solicitarEmprestimo();
                } else {
                    printf("\nRealize o cadastro antes de solicitar um emprestimo.\n");
                }
                break;

            case 4:
                if (cadastroConfirmado == 1) {
                    consultarSaldo(saldo);
                } else {
                    printf("\nRealize o cadastro antes de consultar o saldo.\n");
                }
                break;

            case 0:
                printf("\nObrigado por utilizar o Nubanco.\n");
                printf("Encerrando o sistema...\n");
                break;

            default:
                printf("\nOpcao invalida. Tente novamente.\n");
        }

    } while (opcao != 0);

    return 0;
}

// Exibe as opcoes do menu
void exibirMenu() {
    printf("\n========== MENU PRINCIPAL ==========\n");
    printf("1 - Cadastro de cliente\n");
    printf("2 - Transferencia\n");
    printf("3 - Simulacao de emprestimo\n");
    printf("4 - Consulta de saldo\n");
    printf("0 - Sair\n");
    printf("====================================\n");
}

// Valida o CPF informado
int validarCPF(char cpf[]) {
    if (strlen(cpf) != 11) {
        return 0;
    }

    // Verifica se todos os caracteres sao numeros
    for (int i = 0; i < 11; i++) {
        if (cpf[i] < '0' || cpf[i] > '9') {
            return 0;
        }
    }

    // Rejeita CPFs com todos os digitos iguais
    int todosIguais = 1;

    for (int i = 1; i < 11; i++) {
        if (cpf[i] != cpf[0]) {
            todosIguais = 0;
            break;
        }
    }

    if (todosIguais == 1) {
        return 0;
    }

    int soma = 0;
    int resto;
    int digito1;
    int digito2;

    // Calcula o primeiro digito verificador
    for (int i = 0; i < 9; i++) {
        soma += (cpf[i] - '0') * (10 - i);
    }

    resto = soma % 11;

    if (resto < 2) {
        digito1 = 0;
    } else {
        digito1 = 11 - resto;
    }

    // Calcula o segundo digito verificador
    soma = 0;

    for (int i = 0; i < 9; i++) {
        soma += (cpf[i] - '0') * (11 - i);
    }

    soma += digito1 * 2;

    resto = soma % 11;

    if (resto < 2) {
        digito2 = 0;
    } else {
        digito2 = 11 - resto;
    }

    // Compara os digitos calculados com os informados
    if (digito1 == cpf[9] - '0' &&
        digito2 == cpf[10] - '0') {
        return 1;
    }

    return 0;
}

// Realiza o cadastro do cliente
int cadastrarCliente(char nome[], char cpf[], float *saldo) {
    float saldoInicial;

    printf("\n========== CADASTRO DE CLIENTE ==========\n");

    printf("Digite o nome completo: ");

    if (scanf(" %99[^\n]", nome) != 1) {
        printf("\nNao foi possivel ler o nome informado.\n");
        return 0;
    }

    printf("Digite o CPF (somente numeros): ");

    if (scanf("%11s", cpf) != 1) {
        printf("\nNao foi possivel ler o CPF informado.\n");
        return 0;
    }

    if (validarCPF(cpf) == 0) {
        printf("\nCPF invalido. Cadastro cancelado.\n");
        return 0;
    }

    printf("Digite o saldo inicial da conta: R$ ");

    if (scanf("%f", &saldoInicial) != 1) {
        printf("\nSaldo invalido. Cadastro cancelado.\n");

        int caractere;
        while ((caractere = getchar()) != '\n' &&
               caractere != EOF) {
            // Limpa a entrada invalida
        }

        return 0;
    }

    if (saldoInicial < 0) {
        printf("\nO saldo inicial nao pode ser negativo.\n");
        return 0;
    }

    *saldo = saldoInicial;

    printf("\nCadastro realizado com sucesso!\n");
    printf("Titular: %s\n", nome);
    printf("Saldo inicial: R$ %.2f\n", *saldo);

    return 1;
}

// Realiza uma transferencia
void realizarTransferencia(float *saldo) {
    char destinatario[100];
    float valor;

    printf("\n========== TRANSFERENCIA ==========\n");

    printf("Nome do destinatario: ");

    if (scanf(" %99[^\n]", destinatario) != 1) {
        printf("\nDestinatario invalido.\n");
        return;
    }

    printf("Valor da transferencia: R$ ");

    if (scanf("%f", &valor) != 1) {
        printf("\nValor invalido.\n");

        int caractere;
        while ((caractere = getchar()) != '\n' &&
               caractere != EOF) {
            // Limpa a entrada invalida
        }

        return;
    }

    if (valor <= 0) {
        printf("\nO valor deve ser maior que zero.\n");
        return;
    }

    if (valor > *saldo) {
        printf("\nSaldo insuficiente para realizar a transferencia.\n");
        return;
    }

    *saldo -= valor;

    printf("\nTransferencia realizada com sucesso!\n");
    printf("Destinatario: %s\n", destinatario);
    printf("Valor transferido: R$ %.2f\n", valor);
    printf("Saldo atual: R$ %.2f\n", *saldo);
}

// Simula um emprestimo com juros compostos
void solicitarEmprestimo() {
    float valor;
    float taxa;
    float montante;
    int meses;

    printf("\n========== SIMULACAO DE EMPRESTIMO ==========\n");

    printf("Valor solicitado: R$ ");

    if (scanf("%f", &valor) != 1) {
        printf("\nValor invalido.\n");

        int caractere;
        while ((caractere = getchar()) != '\n' &&
               caractere != EOF) {
            // Limpa a entrada invalida
        }

        return;
    }

    if (valor <= 0) {
        printf("\nO valor deve ser maior que zero.\n");
        return;
    }

    printf("Taxa de juros mensal (%%): ");

    if (scanf("%f", &taxa) != 1) {
        printf("\nTaxa invalida.\n");

        int caractere;
        while ((caractere = getchar()) != '\n' &&
               caractere != EOF) {
            // Limpa a entrada invalida
        }

        return;
    }

    if (taxa < 0) {
        printf("\nA taxa de juros nao pode ser negativa.\n");
        return;
    }

    printf("Prazo em meses: ");

    if (scanf("%d", &meses) != 1) {
        printf("\nPrazo invalido.\n");

        int caractere;
        while ((caractere = getchar()) != '\n' &&
               caractere != EOF) {
            // Limpa a entrada invalida
        }

        return;
    }

    if (meses <= 0) {
        printf("\nO prazo deve ser maior que zero.\n");
        return;
    }

    // Converte a taxa percentual para decimal
    taxa = taxa / 100.0;

    // Calcula o montante com juros compostos
    montante = valor * pow(1 + taxa, meses);

    printf("\n========== RESULTADO DA SIMULACAO ==========\n");
    printf("Valor solicitado: R$ %.2f\n", valor);
    printf("Taxa mensal: %.2f%%\n", taxa * 100);
    printf("Prazo: %d meses\n", meses);
    printf("Juros totais: R$ %.2f\n", montante - valor);
    printf("Montante final: R$ %.2f\n", montante);
    printf("\nEsta simulacao nao representa uma proposta real de credito.\n");
}

// Consulta o saldo atual da conta
void consultarSaldo(float saldo) {
    printf("\n========== CONSULTA DE SALDO ==========\n");
    printf("Saldo disponivel: R$ %.2f\n", saldo);
    printf("=======================================\n");
}
